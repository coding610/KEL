class TransformRectComp:
    def start(self, comps):
        self.xLT = 100
        self.yLT = 100
        self.width = 100
        self.height = 100

    def update(self, comps, objects):
        return comps
