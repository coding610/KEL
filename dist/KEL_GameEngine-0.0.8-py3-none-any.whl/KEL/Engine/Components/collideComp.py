import KEL


class CollideComp:
    def start(self, comps):
        pass

    def update(self, myComps, objects):
        return myComps
