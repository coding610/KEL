# Introduction
NOTE: This is under development and does not have many features.

This is a python Framework called MySEAS (My Sufficiently exploited and Affordable Script). Its build on top of pygame, thefore the name. In the future you might be able to call it a game engine but right now Its a tool i guess.
It (by the moment) does not have a UI and not many features. Of course u can excpect a lot of features in the future.

Anyway here is a code example of how u can use this.

    COPY THE REPO AND RUN TEST2. The codes are only in test2. REMEMBER to activate virtual env.

Its a suprise what this does
This code does not display all of the current features but this is a very simple example and u can go a lot longer.

# Explaining the code (and more)
Too understand whats going on u can do two things. Use ur brain and see what the functions do or look at the documentation.md.

# Download
The procces to download this is quit simple. Just use pip.
Pip command:
pip install MySEAS (If u know what ur doing u can ofc use pip3)

U can also visit the page on pypi here:
https://pypi.org/project/MySEAS/


# Patron
u thought
