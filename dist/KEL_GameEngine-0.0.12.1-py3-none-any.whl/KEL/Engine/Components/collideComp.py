class CollideComp:
    def start(self):
        pass

    def update(self): 
        pass
