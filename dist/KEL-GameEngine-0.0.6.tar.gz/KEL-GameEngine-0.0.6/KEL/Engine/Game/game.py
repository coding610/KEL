from KEL import *


def game():
    print("outdated")


# Security
if __name__ == "__main__":
    game()
