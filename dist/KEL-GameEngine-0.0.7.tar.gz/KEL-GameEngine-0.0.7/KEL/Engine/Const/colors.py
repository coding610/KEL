bgColor = ("#282828")
playerColor = ("#d79921")
