from KEL import *


class name:
    # Called before the first frame
    def start(self):
        pass

    # Called every frame
    def update(self):
        pass
