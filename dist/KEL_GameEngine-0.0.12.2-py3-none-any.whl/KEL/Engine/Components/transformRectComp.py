class TransformRectComp:
    def __init__(self, xLT=100, yLT=100, width=100, height=100) -> None:
        self.xLT = xLT
        self.yLT = yLT 
        self.width = width 
        self.height = height

    def start(self):
        pass

    def update(self):
        pass
