import pygame
pygame.init()


wW, wH = 750, 1000
wn = pygame.display.set_mode((wW, wH))
pygame.display.set_caption("Game Engine", "python icon")
