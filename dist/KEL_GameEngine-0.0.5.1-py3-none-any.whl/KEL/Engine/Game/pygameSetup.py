import pygame
pygame.init()

from KEL.Engine.Const import *

wn = pygame.display.set_mode((wW, wH))
