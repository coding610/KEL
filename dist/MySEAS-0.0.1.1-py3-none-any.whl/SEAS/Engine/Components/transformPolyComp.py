class TransformPoly:
    def __init__(self, point):
        # Make so that u can have many points
        # U might have to update points in update.
        # Make so points are relavant to other points


        # Well do that later
        self.points = point
        self.angle = 0


    def start(self):
        pass

    def update(self):
        pass
